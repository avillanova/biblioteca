def start_mylib():
    print('olá mundo')